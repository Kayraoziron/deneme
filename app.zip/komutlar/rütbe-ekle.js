const Discord = require("discord.js");
const db = require("quick.db");

exports.run = async (client, message, args, tools) => {

let premium = await db.fetch(`premium_${message.guild.id}`)
let rank1 = await db.fetch(`rank1_${message.guild.id}`);
let rank2 = await db.fetch(`rank2_${message.guild.id}`);
let rank3 = await db.fetch(`rank3_${message.guild.id}`);
let rank4 = await db.fetch(`rank4_${message.guild.id}`);
let rank5 = await db.fetch(`rank5_${message.guild.id}`);
let rankdavet1 = await db.fetch(`rankdavet1_${message.guild.id}`);
let rankdavet2 = await db.fetch(`rankdavet2_${message.guild.id}`);
let rankdavet3 = await db.fetch(`rankdavet3_${message.guild.id}`);
let rankdavet4 = await db.fetch(`rankdavet4_${message.guild.id}`);
let rankdavet5 = await db.fetch(`rankdavet5_${message.guild.id}`);
let rank6 = await db.fetch(`rank6_${message.guild.id}`);
let rank7 = await db.fetch(`rank7_${message.guild.id}`);
let rank8 = await db.fetch(`rank8_${message.guild.id}`);
let rank9 = await db.fetch(`rank9_${message.guild.id}`);
let rank10 = await db.fetch(`rank10_${message.guild.id}`);
let rankdavet6 = await db.fetch(`rankdavet6_${message.guild.id}`);
let rankdavet7 = await db.fetch(`rankdavet7_${message.guild.id}`);
let rankdavet8 = await db.fetch(`rankdavet8_${message.guild.id}`);
let rankdavet9 = await db.fetch(`rankdavet9_${message.guild.id}`);
let rankdavet10 = await db.fetch(`rankdave10_${message.guild.id}`);
let rank11 = await db.fetch(`rank11_${message.guild.id}`);
let rank12 = await db.fetch(`rank12_${message.guild.id}`);
let rank13 = await db.fetch(`rank13_${message.guild.id}`); 
let rank14 = await db.fetch(`rank14_${message.guild.id}`);
let rank15 = await db.fetch(`rank15_${message.guild.id}`);
let rankdavet11 = await db.fetch(`rankdavet11_${message.guild.id}`);
let rankdavet12 = await db.fetch(`rankdavet12_${message.guild.id}`);
let rankdavet13 = await db.fetch(`rankdavet13_${message.guild.id}`);
let rankdavet14 = await db.fetch(`rankdavet14_${message.guild.id}`);
let rankdavet15 = await db.fetch(`rankdavet15_${message.guild.id}`);
  
if(!premium){
if(rank5) return message.channel.send(`<:hayir:713216493122224128> Rank Eklemeye Sınırına Ulaştın Premium Alarak 3 Katına Çıkartabilirsin.`);
} else {
if(rank15) return message.channel.send(`<:hayir:713216493122224128> Rank Eklemeye Sınırına Ulaştın.`);
}
  let roluyarı = "<:hayir:713216493122224128> Lütfen Bir Rol Etiketleyin!"
  let davetuyarı = "<:hayir:713216493122224128> Lütfen Davet Miktarı Belirtiniz."
  let zatenekli = "<:hayir:713216493122224128> Bu Rol Zaten Ekli!"
  if(!rank1){
    let davet = args[1];
    let roles = message.mentions.roles.first(); 

    if(!roles) return message.channel.send(roluyarı);
    if(!davet) return message.channel.send(davetuyarı)   
    const embed = new Discord.MessageEmbed()
    .setColor('GREEN')
    .setDescription(`${davet} Davet Karşılığında ${roles} Rolü Verilecektir.`)
    message.channel.send(embed)
    db.set(`rank1_${message.guild.id}`, roles.id) // ROL 1
    db.set(`rankdavet1_${message.guild.id}`, davet) // ROL 1 DAVET
    return;
  }
  if(rank1){
    if(!rank2){
    let davet = args[1];
    let roles = message.mentions.roles.first();
    if(!roles) return message.channel.send(roluyarı);
    if(roles == rank1) return message.channel.send(zatenekli)  
    if(!davet) return message.channel.send(davetuyarı)   
    const embed = new Discord.MessageEmbed()
    .setColor('GREEN')// bi sal aq
    .setDescription(`${davet} Davet Karşılığında ${roles} Rolü Verilecektir.`)
    message.channel.send(embed)
    db.set(`rank2_${message.guild.id}`, roles.id) // ROL 2
    db.set(`rankdavet2_${message.guild.id}`, davet) // ROL 2 DAVET
    return;
    }
  }
   if(rank2){
    if(!rank3){
    let davet = args[1];
    let roles = message.mentions.roles.first();
    if(!roles) return message.channel.send(roluyarı);
     if(roles == rank2) return message.channel.send(zatenekli)
    if(!davet) return message.channel.send(davetuyarı)   
    const embed = new Discord.MessageEmbed()
    .setColor('GREEN')
    .setDescription(`${davet} Davet Karşılığında ${roles} Rolü Verilecektir.`)
    message.channel.send(embed)
    db.set(`rank3_${message.guild.id}`, roles.id) // ROL 3
    db.set(`rankdavet3_${message.guild.id}`, davet) // ROL 3 DAVET
    return;
    }
  }
  if(rank3){
    if(!rank4){
    let davet = args[1];
    let roles = message.mentions.roles.first();
    if(!roles) return message.channel.send(roluyarı);
     if(roles == rank3) return message.channel.send(zatenekli)  
    if(!davet) return message.channel.send(davetuyarı)   
    const embed = new Discord.MessageEmbed()
    .setColor('GREEN')
    .setDescription(`${davet} Davet Karşılığında ${roles} Rolü Verilecektir.`)
    message.channel.send(embed)
    db.set(`rank4_${message.guild.id}`, roles.id) // ROL 4
    db.set(`rankdavet4_${message.guild.id}`, davet) // ROL 4 DAVET
    return;
    }
  }
  if(rank4){
    if(!rank5){
    let davet = args[1];
    let roles = message.mentions.roles.first();
    if(roles == rank4) return message.channel.send(zatenekli)
    if(!roles) return message.channel.send(roluyarı);
    if(!davet) return message.channel.send(davetuyarı)   
    const embed = new Discord.MessageEmbed()
    .setColor('GREEN')
    .setDescription(`${davet} Davet Karşılığında ${roles} Rolü Verilecektir.`)
    message.channel.send(embed)
    db.set(`rank5_${message.guild.id}`, roles.id) // ROL 5
    db.set(`rankdavet5_${message.guild.id}`, davet) // ROL 5 DAVET
    return;
    }
  }
 if(rank5){
    if(!rank6){
    let davet = args[1];
    let roles = message.mentions.roles.first();
    if(!roles) return message.channel.send(roluyarı);
     if(roles == rank5) return message.channel.send(zatenekli)
    if(!davet) return message.channel.send(davetuyarı)   
    const embed = new Discord.MessageEmbed()
    .setColor('GREEN')
    .setDescription(`${davet} Davet Karşılığında ${roles} Rolü Verilecektir.`)
    message.channel.send(embed)
    db.set(`rank6_${message.guild.id}`, roles.id) // ROL 6
    db.set(`rankdavet6_${message.guild.id}`, davet) // ROL 6 DAVET
    return;
    }
 }
   if(rank6){
    if(!rank7){
    let davet = args[1];
    let roles = message.mentions.roles.first();
     if(roles == rank6) return message.channel.send(zatenekli)
    if(!roles) return message.channel.send(roluyarı);
    if(!davet) return message.channel.send(davetuyarı)   
    const embed = new Discord.MessageEmbed()
    .setColor('GREEN')
    .setDescription(`${davet} Davet Karşılığında ${roles} Rolü Verilecektir.`)
    message.channel.send(embed)
    db.set(`rank7_${message.guild.id}`, roles.id) // ROL 7
    db.set(`rankdavet7_${message.guild.id}`, davet) // ROL 7 DAVET
    return;
    }
 }
   if(rank7){
    if(!rank8){
    let davet = args[1];
    let roles = message.mentions.roles.first();
    if(!roles) return message.channel.send(roluyarı);
     if(roles == rank7) return message.channel.send(zatenekli)  
    if(!davet) return message.channel.send(davetuyarı)   
    const embed = new Discord.MessageEmbed()
    .setColor('GREEN')
    .setDescription(`${davet} Davet Karşılığında ${roles} Rolü Verilecektir.`)
    message.channel.send(embed)
    db.set(`rank8_${message.guild.id}`, roles.id) // ROL 8
    db.set(`rankdavet8_${message.guild.id}`, davet) // ROL 8 DAVET
    return;
    }
 }
  if(rank8){
    if(!rank9){
    let davet = args[1];
    let roles = message.mentions.roles.first();
    if(!roles) return message.channel.send(roluyarı);
    if(roles == rank8) return message.channel.send(zatenekli)    
    if(!davet) return message.channel.send(davetuyarı)   
    const embed = new Discord.MessageEmbed()
    .setColor('GREEN')
    .setDescription(`${davet} Davet Karşılığında ${roles} Rolü Verilecektir.`)
    message.channel.send(embed)
    db.set(`rank9_${message.guild.id}`, roles.id) // ROL 9
    db.set(`rankdavet9_${message.guild.id}`, davet) // ROL 9 DAVET
    return;
    }
 }
  if(rank9){
    if(!rank10){
    let davet = args[1];
    let roles = message.mentions.roles.first();
    if(!roles) return message.channel.send(roluyarı);
    if(roles == rank9) return message.channel.send(zatenekli)  
    if(!davet) return message.channel.send(davetuyarı)   
    const embed = new Discord.MessageEmbed()
    .setColor('GREEN')
    .setDescription(`${davet} Davet Karşılığında ${roles} Rolü Verilecektir.`)
    message.channel.send(embed)
    db.set(`rank10_${message.guild.id}`, roles.id) // ROL 10
    db.set(`rankdavet10_${message.guild.id}`, davet) // ROL 10 DAVET
    return;
    }
 }
  if(rank10){
    if(!rank11){
    let davet = args[1];
    let roles = message.mentions.roles.first();
    if(!roles) return message.channel.send(roluyarı);
    if(roles == rank10) return message.channel.send(zatenekli)  
    if(!davet) return message.channel.send(davetuyarı)   
    const embed = new Discord.MessageEmbed()
    .setColor('GREEN')
    .setDescription(`${davet} Davet Karşılığında ${roles} Rolü Verilecektir.`)
    message.channel.send(embed)
    db.set(`rank11_${message.guild.id}`, roles.id) // ROL 11
    db.set(`rankdavet11_${message.guild.id}`, davet) // ROL 11 DAVET
    return;
    }
 }
  if(rank11){
    if(!rank12){
    let davet = args[1];
    let roles = message.mentions.roles.first();
    if(!roles) return message.channel.send(roluyarı);
    if(roles == rank11) return message.channel.send(zatenekli)   
    if(!davet) return message.channel.send(davetuyarı)   
    const embed = new Discord.MessageEmbed()
    .setColor('GREEN')
    .setDescription(`${davet} Davet Karşılığında ${roles} Rolü Verilecektir.`)
    message.channel.send(embed)
    db.set(`rank12_${message.guild.id}`, roles.id) // ROL 12
    db.set(`rankdavet12_${message.guild.id}`, davet) // ROL 12 DAVET
    return;
    }
 }
  if(rank12){
    if(!rank13){
    let davet = args[1];
    let roles = message.mentions.roles.first();
    if(!roles) return message.channel.send(roluyarı);
    if(roles == rank12) return message.channel.send(zatenekli)  
    if(!davet) return message.channel.send(davetuyarı)   
    const embed = new Discord.MessageEmbed()
    .setColor('GREEN')
    .setDescription(`${davet} Davet Karşılığında ${roles} Rolü Verilecektir.`)
    message.channel.send(embed)
    db.set(`rank13_${message.guild.id}`, roles.id) // ROL 13
    db.set(`rankdavet13_${message.guild.id}`, davet) // ROL 13 DAVET
    return;
    }
 }
  if(rank13){
    if(!rank14){
    let davet = args[1];
    let roles = message.mentions.roles.first();
    if(!roles) return message.channel.send(roluyarı);
    if(roles == rank13) return message.channel.send(zatenekli)  
    if(!davet) return message.channel.send(davetuyarı)   
    const embed = new Discord.MessageEmbed()
    .setColor('GREEN')
    .setDescription(`${davet} Davet Karşılığında ${roles} Rolü Verilecektir.`)
    message.channel.send(embed)
    db.set(`rank14_${message.guild.id}`, roles.id) // ROL 14
    db.set(`rankdavet14_${message.guild.id}`, davet) // ROL 14 DAVET
    return;
    }
 }
  if(rank14){
    if(!rank15){
    let davet = args[1];
    let roles = message.mentions.roles.first();
    if(!roles) return message.channel.send(roluyarı);
    if(roles == rank14) return message.channel.send(zatenekli)  
    if(!davet) return message.channel.send(davetuyarı)   
    const embed = new Discord.MessageEmbed()
    .setColor('GREEN')
    .setDescription(`${davet} Davet Karşılığında ${roles} Rolü Verilecektir.`)
    message.channel.send(embed)
    db.set(`rank15_${message.guild.id}`, roles.id) // ROL 15
    db.set(`rankdavet15_${message.guild.id}`, davet) // ROL 15 DAVET
    return;
    }
 }
  
};
exports.conf = {
enabled: true,
guildOnly: true,
aliases: ["rütbe-ekle","addRank","addrank"],
permLevel: 0
};
exports.help = {
name: "rütbe-ekle",
description: 'Davet İle Alınacak Rolleri Ayarlarsınız.',
usage: 'rütbe-ekle <rol> <davet>' 
};