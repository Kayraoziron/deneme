const Discord = require("discord.js"),
  db = require("quick.db");

exports.run = async (client, message, args) => {
  let prefix = (await db.fetch(`prefix_${message.guild.id}`)) || "!";
let rank1 = await db.fetch(`rank1_${message.guild.id}`);
let rank2 = await db.fetch(`rank2_${message.guild.id}`);
let rank3 = await db.fetch(`rank3_${message.guild.id}`);
let rank4 = await db.fetch(`rank4_${message.guild.id}`);
let rank5 = await db.fetch(`rank5_${message.guild.id}`);
let rankdavet1 = await db.fetch(`rankdavet1_${message.guild.id}`);
let rankdavet2 = await db.fetch(`rankdavet2_${message.guild.id}`);
let rankdavet3 = await db.fetch(`rankdavet3_${message.guild.id}`);
let rankdavet4 = await db.fetch(`rankdavet4_${message.guild.id}`);
let rankdavet5 = await db.fetch(`rankdavet5_${message.guild.id}`);
let rank6 = await db.fetch(`rank6_${message.guild.id}`);
let rank7 = await db.fetch(`rank7_${message.guild.id}`);
let rank8 = await db.fetch(`rank8_${message.guild.id}`);
let rank9 = await db.fetch(`rank9_${message.guild.id}`);
let rank10 = await db.fetch(`rank10_${message.guild.id}`);
let rankdavet6 = await db.fetch(`rankdavet6_${message.guild.id}`);
let rankdavet7 = await db.fetch(`rankdavet7_${message.guild.id}`);
let rankdavet8 = await db.fetch(`rankdavet8_${message.guild.id}`);
let rankdavet9 = await db.fetch(`rankdavet9_${message.guild.id}`);
let rankdavet10 = await db.fetch(`rankdave10_${message.guild.id}`);
let rank11 = await db.fetch(`rank11_${message.guild.id}`);
let rank12 = await db.fetch(`rank12_${message.guild.id}`);
let rank13 = await db.fetch(`rank13_${message.guild.id}`); 
let rank14 = await db.fetch(`rank14_${message.guild.id}`);
let rank15 = await db.fetch(`rank15_${message.guild.id}`);
let rankdavet11 = await db.fetch(`rankdavet11_${message.guild.id}`);
let rankdavet12 = await db.fetch(`rankdavet12_${message.guild.id}`);
let rankdavet13 = await db.fetch(`rankdavet13_${message.guild.id}`);
let rankdavet14 = await db.fetch(`rankdavet14_${message.guild.id}`);
let rankdavet15 = await db.fetch(`rankdavet15_${message.guild.id}`);
  if(!rank1){
  const rütbe2 = new Discord.MessageEmbed().setTimestamp().setFooter(`${client.user.username}`,client.user.avatarURL()).setColor('GRAY')
   .setDescription(`Henüz Bir Rütbe Oluşturulmadı.`)
  return message.channel.send(rütbe2)
  }
  let sayı1  
  if(rank1){ sayı1 = `<@&${rank1}> (**${rankdavet1}** Davet)` }
  let sayı2
  if(rank2){ sayı2 = `<@&${rank2}> (**${rankdavet2}** Davet)` } 
  let sayı3
  if(rank3){ sayı3 = `<@&${rank3}> (**${rankdavet3}** Davet)` }
  let sayı4
  if(rank4){ sayı4 = `<@&${rank4}> (**${rankdavet4}** Davet)` }
  let sayı5
  if(rank5){ sayı5 = `<@&${rank5}> (**${rankdavet5}** Davet)` }
  let sayı6
  if(rank6){ sayı6 = `<@&${rank6}> (**${rankdavet6}** Davet)` }
  let sayı7
  if(rank7){ sayı7 = `<@&${rank7}> (**${rankdavet7}** Davet)` }
  let sayı8
  if(rank8){ sayı8 = `<@&${rank8}> (**${rankdavet8}** Davet)` }
  let sayı9
  if(rank9){ sayı9 = `<@&${rank9}> (**${rankdavet9}** Davet)` }
  let sayı10
  if(rank10){ sayı10 = `<@&${rank10}> (**${rankdavet10}** Davet)` }
  let sayı11
  if(rank11){ sayı11 = `<@&${rank11}> (**${rankdavet11}** Davet)` }
  let sayı12
  if(rank12){ sayı12 = `<@&${rank12}> (**${rankdavet12}** Davet)` } 
  let sayı13
  if(rank13){ sayı13 = `<@&${rank13}> (**${rankdavet13}** Davet)` }
  let sayı14
  if(rank14){ sayı14 = `<@&${rank14}> (**${rankdavet14}** Davet)` } 
  let sayı15
  if(rank15){ sayı15 = `<@&${rank15}> (**${rankdavet15}** Davet)` } 

     const rütbe2 = new Discord.MessageEmbed().setTimestamp().setFooter(`${client.user.username}`,client.user.avatarURL()).setTitle('Rütbeler').setColor('GRAY')
    .setDescription(`
${sayı1 ||""}
${sayı2 ||""}
${sayı3 ||""}  
${sayı4 ||""} 
${sayı5 ||""}
${sayı6 ||""}
${sayı7 ||""}
${sayı8 ||""} 
${sayı9 ||""}
${sayı10 ||""} 
${sayı11 ||""}
${sayı12 ||""} 
${sayı13 ||""}   
${sayı14 ||""} 
${sayı15 ||""}`)
   return message.channel.send(rütbe2)
 
};
exports.conf = {
  enabled: true,
  guildOnly: true,
  aliases: ['ranks'],
  permLevel: 0
};
exports.help = {
  name: "rütbe-liste",
  description: "Eklemiş Olduğun Rütbeleri Listeler.",
  usage: "rütbe-liste"
};