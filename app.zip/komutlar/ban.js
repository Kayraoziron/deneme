const Discord = require("discord.js");
const db = require ('quick.db')
const ayarlar = require('../ayarlar.json')

exports.run = (client, message, args) => {
if(!message.member.hasPermission("BAN_MEMBERS")) 
  return message.channel.send(
  new Discord.MessageEmbed()
  .setAuthor('Yetersiz Yetki!', client.user.avatarURL())
  .setColor('BLACK')
  .setDescription('• Bu komutu kullanbilmek için **Üyeleri Yasakla** yetkisine sahip olman gerekiyor!')
  .setTimestamp()
  .setFooter(client.user.username())
  )
  let user = message.mentions.users.first();
  let sebep = args[1];
  if(!user) 
  return message.channel.send(
  new Discord.MessageEmbed()
  .setAuthor('İşlem İptal', client.user.avatarURL())
  .setColor('BLACK')
  .setThumbnail(client.user.avatarURL())
  .setDescription(`• Bir kullanıcı etiketlemelisin. \`\`${ayarlar.prefix}ban @kişi <sebep>\`\``)
  .setTimestamp()
  .setFooter(client.user.username)
  )
  if(!sebep)
  return message.channel.send(
  new Discord.MessageEmbed()
  .setAuthor('İşlem İptal', client.user.avatarURL())
  .setColor('BLACK')
  .setThumbnail(client.user.avatarURL())
  .setDescription(`• Bir sebep yazmayı unuttun. \`\`${ayarlar.prefix}ban @kişi <sebep>\`\``)
  .setTimestamp()
  .setFooter(client.user.username)
  )
  //message.guild.member(user).ban;
  message.channel.send(
  new Discord.MessageEmbed()
  .setAuthor('İşlem Başarılı', client.user.avatarURL())
  .setColor('BLACK')
  .setThumbnail(client.user.avatarURL())
  .setDescription(`**Yetkili Bilgileri** \n• Yetkili : ${message.author} \n• Yetkili Tag : \`\`${message.author.tag}\`\` \n• Yetkili ID : \`\`${message.author.id}\`\` \n\n**Kullanıcı Bilgileri** \n• Kullanıcı : ${user} \n• Kullanıcı Tag : \`\`${user.tag}\`\` \n• Kullanıcı ID : \`\`${user.id}\`\` \n\n• Sebep : **${sebep}**`)
  .setTimestamp()
  .setFooter(client.user.username)
  )
}

exports.conf = {
  enabled: true,
  guildOnly: false,
  aliases: [],
  permLevel: 0  
};

exports.help = {
  name: 'ban',
  description: 'Kişiyi banlar',
  usage: '!ban @üye <sebep>'
}