const Discord = require("discord.js");
const db = require("quick.db"); 

exports.run = async (client, message, args, tools) => {
     let kişi;
    if (message.mentions.users.first()) {
      kişi = message.mentions.users.first();
    } else {
      kişi = message.author;
    }
  
  let davet;
  if (!db.fetch(`davet_${kişi.id}_${message.guild.id}`)) {
    davet = 0;
  } else {
    davet = await db.fetch(`davet_${kişi.id}_${message.guild.id}`);
  }
  

let fake = db.fetch(`fake_${kişi.id}_${message.guild.id}`) || 0
let çıkış = db.fetch(`çıkan_${kişi.id}_${message.guild.id}`) || 0
let bonus = db.fetch(`bonus_${kişi.id}_${message.guild.id}`) || 0

//----- EMBED -----\\
 const rank = new Discord.MessageEmbed()
//.setColor("0xC147EA")
.setAuthor(`${kişi.username}`, kişi.avatarURL())
.setDescription(`
Toplam Davet Sayın : **${davet}** 
Fake Sayılan **${fake}** 
Eklenen Davet : **${bonus}** 
Çıkan : **${çıkış}**`)
.setTimestamp()
.setFooter(client.user.username, client.user.avatarURL());
message.channel.send(rank)
     
};
exports.conf = {
enabled: true,
guildOnly: true,
aliases: ["rank", "invites","invite"],
permLevel: 0
};
exports.help = {
name: "davetlerim",
description: 'Sunucuda Yapılan Davetleri Detalı Şekilde Gösterir.',
usage: 'davetlerim'  
};
