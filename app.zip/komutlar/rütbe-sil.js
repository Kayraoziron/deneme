const Discord = require("discord.js"),
  db = require("quick.db");

exports.run = async (client, message, args) => {
 let rank1 = await db.fetch(`rank1_${message.guild.id}`);
let rank2 = await db.fetch(`rank2_${message.guild.id}`);
let rank3 = await db.fetch(`rank3_${message.guild.id}`);
let rank4 = await db.fetch(`rank4_${message.guild.id}`);
let rank5 = await db.fetch(`rank5_${message.guild.id}`);
let rankdavet1 = await db.fetch(`rankdavet1_${message.guild.id}`);
let rankdavet2 = await db.fetch(`rankdavet2_${message.guild.id}`);
let rankdavet3 = await db.fetch(`rankdavet3_${message.guild.id}`);
let rankdavet4 = await db.fetch(`rankdavet4_${message.guild.id}`);
let rankdavet5 = await db.fetch(`rankdavet5_${message.guild.id}`);
let rank6 = await db.fetch(`rank6_${message.guild.id}`);
let rank7 = await db.fetch(`rank7_${message.guild.id}`);
let rank8 = await db.fetch(`rank8_${message.guild.id}`);
let rank9 = await db.fetch(`rank9_${message.guild.id}`);
let rank10 = await db.fetch(`rank10_${message.guild.id}`);
let rankdavet6 = await db.fetch(`rankdavet6_${message.guild.id}`);
let rankdavet7 = await db.fetch(`rankdavet7_${message.guild.id}`);
let rankdavet8 = await db.fetch(`rankdavet8_${message.guild.id}`);
let rankdavet9 = await db.fetch(`rankdavet9_${message.guild.id}`);
let rankdavet10 = await db.fetch(`rankdave10_${message.guild.id}`);
let rank11 = await db.fetch(`rank11_${message.guild.id}`);
let rank12 = await db.fetch(`rank12_${message.guild.id}`);
let rank13 = await db.fetch(`rank13_${message.guild.id}`); 
let rank14 = await db.fetch(`rank14_${message.guild.id}`);
let rank15 = await db.fetch(`rank15_${message.guild.id}`);
let rankdavet11 = await db.fetch(`rankdavet11_${message.guild.id}`);
let rankdavet12 = await db.fetch(`rankdavet12_${message.guild.id}`);
let rankdavet13 = await db.fetch(`rankdavet13_${message.guild.id}`);
let rankdavet14 = await db.fetch(`rankdavet14_${message.guild.id}`);
let rankdavet15 = await db.fetch(`rankdavet15_${message.guild.id}`);
let roles = message.mentions.roles.first();
if(!roles) return message.channel.send('Silinecek Rank Rolünü Etiketleyiniz.')
if(roles == rank1) {
db.delete(`rank1_${message.guild.id}`)
db.delete(`rankdavet1_${message.guild.id}`)  
const başarılı = new Discord.MessageEmbed()  
.setColor('GREEN')
.setDescription(`${roles} Rankını Sildim.`)
return message.channel.send(başarılı)
} 
if(roles == rank2) {
db.delete(`rank2_${message.guild.id}`)
db.delete(`rankdavet2_${message.guild.id}`)  
const başarılı = new Discord.MessageEmbed()  
.setColor('GREEN')
.setDescription(`${roles} Rankını Sildim.`)
return message.channel.send(başarılı) 
} 
if(roles == rank3) {
db.delete(`rank3_${message.guild.id}`)
db.delete(`rankdavet3_${message.guild.id}`)  
const başarılı = new Discord.MessageEmbed()  
.setColor('GREEN')
.setDescription(`${roles} Rankını Sildim.`)
return message.channel.send(başarılı)  
}
if(roles == rank4) {
db.delete(`rank4_${message.guild.id}`)
db.delete(`rankdavet4_${message.guild.id}`)  
const başarılı = new Discord.MessageEmbed()  
.setColor('GREEN')
.setDescription(`${roles} Rankını Sildim.`)
return message.channel.send(başarılı)  
}
if(roles == rank5) {
db.delete(`rank5_${message.guild.id}`)
db.delete(`rankdavet5_${message.guild.id}`)  
const başarılı = new Discord.MessageEmbed()  
.setColor('GREEN')
.setDescription(`${roles} Rankını Sildim.`)
return message.channel.send(başarılı)  
}    
  
};
exports.conf = {
  enabled: true,// çalışşş
  guildOnly: true,
  aliases: ['removeRank','removerank','rütbesil'],
  permLevel: 2
};
exports.help = {
  name: "rütbe-sil",
  description: "rütbe-sil",
  usage: "rütbe-sil"
};