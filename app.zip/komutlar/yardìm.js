 const Discord = require('discord.js'); 
 
exports.run = async(client, message, args) => {
 
 const Embed = new Discord.MessageEmbed()
 .setTimestamp()
 .setThumbnail(client.user.avatarURL())
 .setAuthor("Code's Invite", client.user.avatarURL())
 .setColor("BLACK")
 .setTitle("")
 .setDescription(`Code's | BotList için tasarlanmış **Davet Sistemi** botudur.`)
 .addField("Davet Komutları", `
Davet için gerekli komutlar;
\`davet-kanal-ayarla\`,\`davet-kanal-sıfırla\`,\`davet-ödül-log\`,\`davet-ekle\`,\`davet-sil\`,\`davet-sıfırla\`
`)
 .addField("Rütbe Komutları", `
Rütbe için gerekli komutlar;
\`rütbe-ekle\`,\`rütbe-sil\`,\`rütbe-liste\`
`)
 
 .addField("Genel Komutlar", `
Herkesin kullanabileceği komutlar;
\`ping\`,\`davetlerim\`,\`rütbe-liste\`, \`istatistik\`, \`sunucu-bilgi\`
`)
.setFooter(client.user.username, client.user.avatarURL())
 message.channel.send(Embed)
}

module.exports.conf = {
  enabled: true,
  guildOnly: false,
  aliases: ["yardım","help","h","help"],
  permLevel: 0
};

module.exports.help = {
  name: 'yardım',
  description: 'Yardım Menüsünü Gösterir.',
  usage: 'yardım'
};
